package com.ufc.br.api_gateway.dto;

public record LoginDTO(String email, String password) {
}
