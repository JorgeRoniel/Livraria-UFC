const VITE_API_BASE_URL = "http://localhost:8080";
const VITE_NOTIFICATIONS_WS_URL = "ws://localhost:8765";

export { VITE_API_BASE_URL, VITE_NOTIFICATIONS_WS_URL };
